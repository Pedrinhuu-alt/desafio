// Adiciona um efeito de scroll ao aparecer a seção "serviços"
window.addEventListener('scroll', function() {
    const servicosSection = document.querySelector('.servicos');
    const sectionPosition = servicosSection.getBoundingClientRect().top;
    const screenPosition = window.innerHeight / 1.5;

    if (sectionPosition < screenPosition) {
        servicosSection.classList.add('visible');
    }
});

// Animação para a rolagem suave ao clicar em links de navegação
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        target.scrollIntoView({
            behavior: 'smooth'
        });
    });
});
  