import axios from 'axios'
import { useEffect, useState } from 'react'
import ProductItem from './ProductItem'

export default function ProductList() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    axios.get('http://localhost:3001/products').then(res => {
      setProducts(res.data)
    })
  }, [])

  return (
    <div>
      <h2>Produtos</h2>
      {products.map(prod => (
        <ProductItem key={prod.id} product={prod} />
      ))}
    </div>
  )
}
