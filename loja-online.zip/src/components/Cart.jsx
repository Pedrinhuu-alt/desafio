import { useEffect, useState } from 'react'

export default function Cart() {
  const [items, setItems] = useState([])

  useEffect(() => {
    const cart = JSON.parse(localStorage.getItem('cart')) || []
    setItems(cart)
  }, [])

  function remove(index) {
    const newCart = [...items]
    newCart.splice(index, 1)
    localStorage.setItem('cart', JSON.stringify(newCart))
    setItems(newCart)
  }

  const total = items.reduce((sum, item) => sum + item.price, 0)

  return (
    <div>
      <h2>Carrinho</h2>
      {items.map((item, index) => (
        <div key={index}>
          {item.name} - R$ {item.price.toFixed(2)} 
          <button onClick={() => remove(index)}>Remover</button>
        </div>
      ))}
      <h3>Total: R$ {total.toFixed(2)}</h3>
    </div>
  )
}
