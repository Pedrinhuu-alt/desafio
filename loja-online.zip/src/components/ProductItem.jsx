import { Link } from 'react-router-dom'

export default function ProductItem({ product }) {
  function addToCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || []
    cart.push(product)
    localStorage.setItem('cart', JSON.stringify(cart))
  }

  return (
    <div style={{ border: '1px solid #ccc', margin: 10, padding: 10 }}>
      <img src={product.image} width={100} />
      <h3>{product.name}</h3>
      <p>{product.price.toFixed(2)}</p>
      <button onClick={addToCart}>Adicionar ao Carrinho</button>
      <br />
      <Link to={`/produto/${product.id}`}>Ver detalhes</Link>
    </div>
  )
}
