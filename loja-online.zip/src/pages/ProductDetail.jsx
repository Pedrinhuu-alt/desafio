import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import axios from 'axios'

export default function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)

  useEffect(() => {
    axios.get(`http://localhost:3001/products/${id}`).then(res => {
      setProduct(res.data)
    })
  }, [id])

  if (!product) return <p>Carregando...</p>

  return (
    <div>
      <h2>{product.name}</h2>
      <img src={product.image} width={200} />
      <p>{product.description}</p>
      <p>Preço: R$ {product.price.toFixed(2)}</p>
    </div>
  )
}
